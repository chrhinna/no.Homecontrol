# Homecontrol Zigbee

This app allows you to connect your Homecontrol devices to Homey

# Supported Devices

* HC GU10 bulb
* HC E27 bulb
* Develco zhwr202

# Devices in progress

* HCO (Dual plug)
* HC Motion sensor
* HC Door/Window sensor

# Version 0.0.5
Started process of adding new devices:
* HC Motion sensor
* HC Door/Window sensor

# Version 0.0.4
Initial commit

** This app is based of INNR Lightning - Thanks to Kasteleman!
