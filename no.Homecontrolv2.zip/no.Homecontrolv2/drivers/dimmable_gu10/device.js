'use strict';

const ZigBeeLightDevice = require('homey-meshdriver').ZigBeeLightDevice;
const maxDim = 254;

class DimmableGU10 extends ZigBeeLightDevice {

}

module.exports = DimmableGU10;
